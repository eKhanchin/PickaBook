package com.hitorus.pick_a_book;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.view.ContextThemeWrapper;
import androidx.appcompat.widget.PopupMenu;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import static android.content.Context.CLIPBOARD_SERVICE;

public class AllBooksFragment extends Fragment{
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager mLayoutManager;
    private RecyclerView.Adapter mAdapter;
    private ArrayList<Book> mBooks;
    private Book mSelectedBook;
    private int mBookPosition;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflates the layout for this fragment
        return inflater.inflate(R.layout.fragment_all_books, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        mRecyclerView = view.findViewById(R.id.allBooksRecyclerView);

        // Improves performance, layout size of the RecyclerView does not change
        mRecyclerView.setHasFixedSize(true);

        mLayoutManager = new LinearLayoutManager(getActivity());
        mRecyclerView.setLayoutManager(mLayoutManager);

        final DbHandler dbHandler = new DbHandler(getActivity());
        mBooks = dbHandler.loadBooks();
        sortBooksList(mBooks);

        mAdapter = new BooksAdapter(mBooks, view.getContext(), this);
        mRecyclerView.setAdapter(mAdapter);
    }

    /**
     * Sorts list of books so that finished books are at the end of the list.
     * @param mBooks - list of books.
     */
    private void sortBooksList(ArrayList<Book> mBooks)
    {
        ArrayList<Book> statusFinishedBooks = new ArrayList<>();
        ArrayList<Book> statusPendingAndReadingBooks = new ArrayList<>();

        for (Book book : mBooks)
        {
            if (book.getStatus() == Book.Status.FINISHED) statusFinishedBooks.add(book);
            else statusPendingAndReadingBooks.add(book);
        }

        statusPendingAndReadingBooks.addAll(statusFinishedBooks);

        this.mBooks = statusPendingAndReadingBooks;
    }

    /**
     * Saves selected book and it's position in a list and opens popup menu
     * @param view - current selected view in RecyclerView
     * @param position - position of a view in a list
     */
    public void showBookPopupMenu(View view, int position)
    {
        mSelectedBook = mBooks.get(position);
        mBookPosition = position;

        Context wrapper = new ContextThemeWrapper(getContext(), R.style.pickABookPopupMenuStyle);
        PopupMenu popup = new PopupMenu(wrapper, view);
        popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                bookMenuItemClick(item);
                return true;
            }
        });
        popup.inflate(R.menu.book_popup_menu);
        popup.show();
    }

    /**
     * Menu item press callback
     * @param item - pressed menu item
     * @return boolean - true when option selected, false otherwise
     */
    public boolean bookMenuItemClick(MenuItem item) {

        DbHandler dbHandler = new DbHandler(getContext());

        switch (item.getItemId())
        {
            case R.id.startReadingOption:
                startReading(dbHandler);
                return true;

            case R.id.finishReadingOption:
                finishReading(dbHandler);
                return true;

            case R.id.clearStatusOption:
                clearStatus(dbHandler);
                return true;

            case R.id.copyNameOption:
                copyBookAuthorNames();
                return true;

            case R.id.renameOption:
                displayBookRenameDialog();
                return true;

            case R.id.deleteBookOption:
                displayDeleteBookDialog();
                return true;

            default:
                return false;
        }
    }

    /**
     * Changes book's status to READING
     * @param dbHandler - database handler
     */
    public void startReading(DbHandler dbHandler) {
        changeStatus(dbHandler, "READING", R.string.changedStatusToReadingToast);
    }

    /**
     * Changes book's status to FINISHED
     * @param dbHandler - database handler
     */
    public void finishReading(DbHandler dbHandler) {
        changeStatus(dbHandler, "FINISHED", R.string.changedStatusToFinishedToast);
    }

    /**
     * Clear book's status - changes it to PENDING
     * @param dbHandler
     */
    public void clearStatus(DbHandler dbHandler) {
        changeStatus(dbHandler, "PENDING", R.string.changedStatusToPendingToast);
    }

    /**
     * Changes book's status
     * @param dbHandler - database handler
     * @param status - book's new status
     * @param toastStringId - id of a string to display as toast
     */
    public void changeStatus(DbHandler dbHandler, String status, int toastStringId) {

        String[] newValues = new String[3];
        newValues[0] = mSelectedBook.getName();
        newValues[1] = mSelectedBook.getAuthor();
        newValues[2] = status;

        dbHandler.updateBook(mSelectedBook, newValues);
        mSelectedBook.setStatus(Book.Status.valueOf(status));
        this.mBooks.set(mBookPosition, mSelectedBook);
        this.mAdapter.notifyDataSetChanged();
        Toast.makeText(getContext(), toastStringId, Toast.LENGTH_LONG).show();
    }

    /**
     * Copies book's or author's name to the clipboard
     */
    public void copyBookAuthorNames()
    {
        final android.content.ClipboardManager clipboardManager =
                (ClipboardManager) getContext().getSystemService(CLIPBOARD_SERVICE);

        ClipData clipData = ClipData.newPlainText("Source Text",
                "\"" + mBooks.get(mBookPosition).getName() + "\", "
                        + mBooks.get(mBookPosition).getAuthor());

        clipboardManager.setPrimaryClip(clipData);
        Toast.makeText(getContext(), R.string.copyObjectToast,
                Toast.LENGTH_LONG).show();
    }

    /**
     * Displays a dialog that allows to rename selected book
     */
    public void displayBookRenameDialog() {
        DialogFragment dialog = BookRenameDialogFragment.newInstance(mSelectedBook);
        dialog.show(getActivity().getSupportFragmentManager(), "BookRenameDialogFragment");
    }

    /**
     * Renames selected book
     * @param dialog - a dialog that allows to enter a new name
     */
    public void renameBook(BookRenameDialogFragment dialog) {
        EditText newBookNameEditText = dialog.getBookRenameEditText();
        String bookString = newBookNameEditText.getText().toString();
        String[] names = bookString.split("[, ]+");

        String[] newValues = new String[3];
        newValues[0] = names[0];
        newValues[1] = names[1];
        newValues[2] = mSelectedBook.getStatus().toString();

        DbHandler dbHandler = new DbHandler(getActivity());
        dbHandler.updateBook(mSelectedBook, newValues);

        mSelectedBook.setName(names[0]);
        mSelectedBook.setAuthor(names[1]);
        this.mBooks.set(mBookPosition, mSelectedBook);
        this.mAdapter.notifyDataSetChanged();
        Toast.makeText(getContext(), R.string.bookRenameToast, Toast.LENGTH_LONG).show();
    }

    /**
     * Displays a dialog that allows to delete selected book
     */
    public void displayDeleteBookDialog() {
        DialogFragment dialog = DeleteBookDialogFragment.newInstance(mSelectedBook);
        dialog.show(getActivity().getSupportFragmentManager(), "DeleteBookDialogFragment");
    }

    /**
     * Deletes selected book
     */
    public void deleteBook() {
        DbHandler dbHandler = new DbHandler(getActivity());
        dbHandler.deleteBook(mBooks.get(mBookPosition).getName(),
                mBooks.get(mBookPosition).getAuthor());
        this.mBooks.remove(mBookPosition);
        this.mAdapter.notifyDataSetChanged();
        Toast.makeText(getContext(), R.string.deleteBookToast, Toast.LENGTH_LONG).show();
    }
}
